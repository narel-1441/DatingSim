/**
 * 
 */
/**
 * @author Narel
 *
 */
module DatingSim {
	requires java.desktop;
}